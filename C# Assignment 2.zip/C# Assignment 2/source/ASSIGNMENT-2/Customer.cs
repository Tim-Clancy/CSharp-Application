﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ASSIGNMENT_2
{
    public class Customer
    {
        public int ID { get; set; }
        public string name { get; set; }

        MeContext meContext = new MeContext();

        public Customer()
        {

        }

        public Customer(string name)
        {
            this.name = name;
        }

        public void addNewCustomer(string c)
        {
            Customer a = new Customer(c);
            meContext.Customers.Add(a);
            meContext.SaveChanges();
            Console.WriteLine("Customer Added");
            Thread.Sleep(3000);

        }

        public void removeCustomer(List<Customer> c)
        {
            for (int i = 0; i < c.Count; i++)
            {
                Console.WriteLine(c[i].ToString());
            }
            Console.WriteLine("Please Specify the Full Name of the person You would like to remove");
            string name1 = Console.ReadLine().ToUpper();
            var db = meContext.Customers.Where(u => u.name.ToUpper().Equals(name1)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Removed: " + db.ToString());
                meContext.Customers.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }

        }


        public override string ToString()
        {
            string s = name;
            return s;
        }

    }
}
