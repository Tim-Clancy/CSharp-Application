﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Data.Entity;

namespace ASSIGNMENT_2
{
    class MeContext : DbContext
    {
        public MeContext() : base(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Patrick\OneDrive\Desktop\ASSIGNMENT-2-TIM-CLANCY-ADVANCED-PROGRAMMING\ASSIGNMENT-2-TIM-CLANCY-ADVANCED-PROGRAMMING\source\ASSIGNMENT-2\Vehicles.mdf;Integrated Security=True;Connect Timeout=30") {}
        public DbSet<Vehicles> Vehicle { get; set; }
        public DbSet<Refuel> Refuel { get; set; }
        public DbSet<Repair> Repair { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Rental> Rentals { get; set; }
    }
}
