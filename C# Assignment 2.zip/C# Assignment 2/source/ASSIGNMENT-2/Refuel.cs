﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASSIGNMENT_2
{
    public class Refuel
    {
        public int ID { get; set; }
        public string GetRegPlate { get; set; }
        public double GetRentalPrice { get; set; }
        public string GetVehicleType { get; set; }
        public string GetFuelType { get; set; }
        public string GetMake { get; set; }
        public string GetModel { get; set; }
        public string GetBodyType { get; set; }
        public string GetColor { get; set; }
        public string GetRental { get; set; }
        public int GetMileage { get; set; }

        public int fuelLvl;

        MeContext meContext = new MeContext();
        public Refuel()
        {

        }

        public Refuel(int fuelLvl, string getRegPlate, double getRentalPrice, string getVehicleType, string getFuelType, string getMake, string getModel, string getBodyType, string getColor, string getRental, int getMileage)
        {
            this.fuelLvl = fuelLvl;
            this.GetRegPlate = getRegPlate;
            this.GetRentalPrice = getRentalPrice;
            this.GetVehicleType = getVehicleType;
            this.GetFuelType = getFuelType;
            this.GetMake = getMake;
            this.GetModel = getModel;
            this.GetBodyType = getBodyType;
            this.GetColor = getColor;
            this.GetRental = getRental;
            this.GetMileage = getMileage;
        }

        public string refuelVehicle(Vehicles a)
        {
            
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;


            Refuel v = new Refuel(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);

            meContext.Refuel.Add(v);
            meContext.SaveChanges();

            string s = "success";
            return s;

        }

        public void refuelAVehicle(List<Vehicles> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please specify by registration plate the vehicle you would like to Refuel:");
            string reg = Console.ReadLine().ToUpper();
            var db = meContext.Vehicle.Where(u => u.GetRegPlate.ToUpper().Equals(reg)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Refueling: " + db.ToString());
                refuelVehicle(db);
                meContext.Vehicle.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }
        }

        public void returnFromRefuel(List<Refuel> a, Vehicles b)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please specify by registration plate the vehicle you would like to Return from refueling:");
            string reg = Console.ReadLine().ToUpper();
            var db = meContext.Refuel.Where(u => u.GetRegPlate.ToUpper().Equals(reg)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Refueled: " + db.ToString());
                b.returnRef(db);
                meContext.Refuel.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }

        }

        public override string ToString()
        {
            string a = GetRegPlate + " " + GetRentalPrice.ToString() + " " + GetVehicleType + " " + GetMake + " " + GetModel + " " + GetBodyType + " " + GetColor + " " + GetRental + " " + GetMileage.ToString() + " " + fuelLvl.ToString();
            return a;
        }
    }
}
