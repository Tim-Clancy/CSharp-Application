﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASSIGNMENT_2
{
    public class Rental
    {
        public int ID { get; set; }
        public string GetRegPlate { get; set; }
        public double GetRentalPrice { get; set; }
        public string GetVehicleType { get; set; }
        public string GetFuelType { get; set; }
        public string GetMake { get; set; }
        public string GetModel { get; set; }
        public string GetBodyType { get; set; }
        public string GetColor { get; set; }
        public string GetRental { get; set; }
        public int GetMileage { get; set; }
        public int fuelLvl;
        public string Name { get; set; }

        MeContext meContext = new MeContext();

        public Rental()
        {

        }

        public Rental(string regPlate, double rentalPrice, string vehicleType, string fuelType, string make, string model, string bodyType, string color, string rental, int mileage, int fuelLvl, string n)
        {
            this.GetRegPlate = regPlate;
            this.GetRentalPrice = rentalPrice;
            this.GetVehicleType = vehicleType;
            this.GetFuelType = fuelType;
            this.GetMake = make;
            this.GetModel = model;
            this.GetBodyType = bodyType;
            this.GetColor = color;
            this.GetRental = rental;
            this.GetMileage = mileage;
            this.fuelLvl = fuelLvl;
            this.Name = n;
        }

        
        
        
        
        
        public void addRentals(Vehicles v, Customer c)
        {
            string GetRegPlate = v.GetRegPlate;
            double GetRentalPrice = v.GetRentalPrice;
            string GetVehicleType = v.GetVehicleType;
            string GetFuelType = v.GetFuelType;
            string GetMake = v.GetMake;
            string GetModel = v.GetModel;
            string GetBodyType = v.GetBodyType;
            string GetColor = v.GetColor;
            string GetRental = "Rented";
            int GetMileage = v.GetMileage;
            int fuelLvl = v.fuelLvl;
            string Name = c.name;

            Rental r = new Rental(GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage, fuelLvl, Name);

            meContext.Rentals.Add(r);
            meContext.SaveChanges();

        }

        public void returnVehicle(Rental a)
        {
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;


            Vehicles v = new Vehicles(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);

            meContext.Vehicle.Add(v);
            meContext.SaveChanges();

        }
  

        public void viewAllRentals(List<Rental> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Would you like to view a specific vehicle type? (Y/N)");
            string choice = Console.ReadLine();
            if (choice.ToLower() == "y")
            {
                Console.Clear();
                Console.WriteLine("Please Specify the Vehicle Type You would like to see: (I.E MotorBike)");
                string choice2 = Console.ReadLine().ToUpper();
                var db1 = meContext.Vehicle.Where(u => u.GetVehicleType.ToUpper().Equals(choice2)).FirstOrDefault();
                if (db1 == null) { Console.WriteLine("No Records Found"); }
                else 
                {
                    Console.WriteLine(db1.ToString()); 
                    Thread.Sleep(3000);
                }
                
            }

        }

        public void viewAllCurrentCustomers(List<Rental> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].Name);
            }
            Thread.Sleep(3000);

        }

        public void viewSpecCustomer(List<Rental> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Thread.Sleep(3000);
            Console.WriteLine("Please Specify the Customer by full name You would like to see: ");
            string choice = Console.ReadLine().ToUpper();
            var db1 = meContext.Customers.Where(u => u.name.ToUpper().Equals(choice)).FirstOrDefault();
            if (db1 == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine(db1.ToString());
                Thread.Sleep(3000);
            }
        }

        public void addNewRental(List<Vehicles> a, List<Customer> b)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("\n\n");
            for (int i = 0; i < b.Count; i++)
            {
                Console.WriteLine(b[i].ToString());
            }
            Console.WriteLine("Please Specify the Vehicle You would like to Rent out by Registration plate: ");
            string choice = Console.ReadLine().ToUpper();
            var db1 = meContext.Vehicle.Where(u => u.GetRegPlate.ToUpper().Equals(choice)).FirstOrDefault();
            if (db1 == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Now, Please Specify the Customer who is renting the vehicle by full name: ");
                string choice2 = Console.ReadLine().ToUpper();
                var db2 = meContext.Customers.Where(u => u.name.ToUpper().Equals(choice2)).FirstOrDefault();
                if (db2 == null) { Console.WriteLine("No Records Found"); }
                else
                {
                    Console.WriteLine("Rental Added");
                    addRentals(db1, db2);
                    meContext.Vehicle.Remove(db1);
                    meContext.SaveChanges();
                    Thread.Sleep(3000);
                }
            }
        }

        public void returnRental(List<Rental> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please Specify the Vehicle You would like to Return by Registration plate: ");
            string choice = Console.ReadLine().ToUpper();
            var db = meContext.Rentals.Where(u => u.GetRegPlate.ToUpper().Equals(choice)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Rental Removed");
                returnVehicle(db);
                meContext.Rentals.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }


        }

        public override string ToString()
        {
            string s = GetRegPlate + " " + GetRentalPrice.ToString() + " " + GetVehicleType + " " + GetMake + " " + GetModel + " " + GetBodyType + " " + GetColor + " " + GetRental + " " + GetMileage.ToString() + " " + fuelLvl.ToString() + " " + Name;
            return s;
        }
    }
}
