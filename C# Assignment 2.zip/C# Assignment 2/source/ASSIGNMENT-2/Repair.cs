﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASSIGNMENT_2
{
    public class Repair
    {

        public int ID { get; set; }
        public string GetRegPlate { get; set; }
        public double GetRentalPrice { get; set; }
        public string GetVehicleType { get; set; }
        public string GetFuelType { get; set; }
        public string GetMake { get; set; }
        public string GetModel { get; set; }
        public string GetBodyType { get; set; }
        public string GetColor { get; set; }
        public string GetRental { get; set; }
        public int GetMileage { get; set; }

        public int fuelLvl;

        MeContext meContext = new MeContext();

        public Repair()
        {

        }

        public Repair(int fuelLvl, string getRegPlate, double getRentalPrice, string getVehicleType, string getFuelType, string getMake, string getModel, string getBodyType, string getColor, string getRental, int getMileage)
        {
            this.fuelLvl = fuelLvl;
            this.GetRegPlate = getRegPlate;
            this.GetRentalPrice = getRentalPrice;
            this.GetVehicleType = getVehicleType;
            this.GetFuelType = getFuelType;
            this.GetMake = getMake;
            this.GetModel = getModel;
            this.GetBodyType = getBodyType;
            this.GetColor = getColor;
            this.GetRental = getRental;
            this.GetMileage = getMileage;
        }

        public string repair(Vehicles a)
        {
            
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;
            Repair v = new Repair(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);
            meContext.Repair.Add(v);
            meContext.SaveChanges();
            string s = "success";
            return s;

        }

        public void repairVehicle(List<Vehicles> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please specify by registration plate of the vehicle you would like to Repair:");
            string reg = Console.ReadLine().ToUpper();
            var db = meContext.Vehicle.Where(u => u.GetRegPlate.ToUpper().Equals(reg)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Repairing: " + db.ToString());
                repair(db);
                meContext.Vehicle.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }
        }

        public void returnFromRepair(List<Repair> a, Vehicles b)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please specify by registration plate the vehicle you would like to Return from Repair:");
            string reg = Console.ReadLine().ToUpper();
            var db = meContext.Repair.Where(u => u.GetRegPlate.ToUpper().Equals(reg)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Repaired: " + db.ToString());
                b.returnRep(db);
                meContext.Repair.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }

        }
        public override string ToString()
        {
            string s = GetRegPlate + " " + GetRentalPrice.ToString() + " " + GetVehicleType + " " + GetMake + " " + GetModel + " " + GetBodyType + " " + GetColor + " " + GetRental + " " + GetMileage.ToString() + " " + fuelLvl.ToString();
            return s;
        }
    }
}
