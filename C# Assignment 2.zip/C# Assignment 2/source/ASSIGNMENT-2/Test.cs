﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASSIGNMENT_2
{
    class Test
    {
        static void Main(string[] args)
        {
            
            var meContext = new MeContext();
            Rental r = new Rental();
            Vehicles v = new Vehicles();
            Customer c = new Customer();
            Refuel re = new Refuel();
            Repair rep = new Repair();
            bool exit = false;
            while(exit == false)
            {
                List<Vehicles> vehicles = meContext.Vehicle.ToList();
                List<Customer> customers = meContext.Customers.ToList();
                List<Rental> rental = meContext.Rentals.ToList();
                List<Refuel> refuel = meContext.Refuel.ToList();
                List<Repair> repair = meContext.Repair.ToList();

                Console.Clear();
                Console.WriteLine("Welcome Admin, Please select What you would like to do:" +
                "\nA) • View a list of vehicles currently rented Vehicles" +
                "\nB) • View a list of customers which have a vehicle rented out" +
                "\nC) • View a list of vehicles rented out by a specific customer" +
                "\nD) • Rent a vehicle to a customer" +
                "\nE) • Return a vehicle from a customer" +
                "\nF) • Record that a vehicle has been sent for refuelling" +
                "\nG) • Record that a vehicle has been returned from refuelling" +
                "\nH) • Record that a vehicle needs maintenance and is not available for rental" +
                "\nI) • Record that a vehicle is back from maintenance and is available for rental" +
                "\nJ) • Adding a vehicle to the system" +
                "\nK) • Removing a vehicle " +
                "\nL) • Adding a customer" +
                "\nM) • Removing a customer");
                string choice = Console.ReadLine();

                switch (choice.ToLower())
                {
                    case "a":
                        Console.Clear();
                        r.viewAllRentals(rental);
                        break;
                    case "b":
                        Console.Clear();
                        r.viewAllCurrentCustomers(rental);
                        break;
                    case "c":
                        Console.Clear();
                        r.viewSpecCustomer(rental);
                        break;
                    case "d":
                        Console.Clear();
                        r.addNewRental(vehicles, customers);
                        break;
                    case "e":
                        Console.Clear();
                        r.returnRental(rental);
                        break;
                    case "f":
                        Console.Clear();
                        re.refuelAVehicle(vehicles);
                        break;
                    case "g":
                        Console.Clear();
                        re.returnFromRefuel(refuel, v);
                        break;
                    case "h":
                        Console.Clear();
                        rep.repairVehicle(vehicles);
                        break;
                    case "i":
                        Console.Clear();
                        rep.returnFromRepair(repair, v);
                        break;
                    case "j":
                        Console.Clear();
                        v.addVehicles(v);
                        break;
                    case "k":
                        Console.Clear();
                        v.removeVehicles(vehicles);
                        break;
                    case "l":
                        Console.Clear();
                        Console.WriteLine("Please enter the Full Name of the new customer");
                        c.name = Console.ReadLine();
                        c.addNewCustomer(c.name);
                        break;
                    case "m":
                        Console.Clear();
                        c.removeCustomer(customers);
                        break;
                }
            }
            


    


            



        }
    }
}
