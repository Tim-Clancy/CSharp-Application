﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace ASSIGNMENT_2
{
    public class Vehicles
    {
        public int ID { get; set; }
        public string GetRegPlate { get; set; }
        public double GetRentalPrice { get; set; }
        public string GetVehicleType { get; set; }
        public string GetFuelType { get; set; }
        public string GetMake { get; set; }
        public string GetModel { get; set; }
        public string GetBodyType { get; set; }
        public string GetColor { get; set; }
        public string GetRental { get; set; }
        public int GetMileage { get; set; }

        public int fuelLvl;

        MeContext meContext = new MeContext();
        public Vehicles()
        {

        }

        public Vehicles(int fuelLvl, string getRegPlate, double getRentalPrice, string getVehicleType, string getFuelType, string getMake, string getModel, string getBodyType, string getColor, string getRental, int getMileage)
        {
            this.fuelLvl = fuelLvl;
            this.GetRegPlate = getRegPlate;
            this.GetRentalPrice = getRentalPrice;
            this.GetVehicleType = getVehicleType;
            this.GetFuelType = getFuelType;
            this.GetMake = getMake;
            this.GetModel = getModel;
            this.GetBodyType = getBodyType;
            this.GetColor = getColor;
            this.GetRental = getRental;
            this.GetMileage = getMileage;
        }

        public void addVehicle(Vehicles a)
        {
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;
            Vehicles v  = new Vehicles(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);
            meContext.Vehicle.Add(v);
            meContext.SaveChanges();

        }

        public void returnRef(Refuel a)
        { 
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;
            Vehicles v = new Vehicles(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);
            meContext.Vehicle.Add(v);
            meContext.SaveChanges();

        }
        public void returnRep(Repair a)
        {
            string GetRegPlate = a.GetRegPlate;
            double GetRentalPrice = a.GetRentalPrice;
            string GetVehicleType = a.GetVehicleType;
            string GetFuelType = a.GetFuelType;
            string GetMake = a.GetMake;
            string GetModel = a.GetModel;
            string GetBodyType = a.GetBodyType;
            string GetColor = a.GetColor;
            string GetRental = "Available";
            int GetMileage = a.GetMileage;
            int fuelLvl = a.fuelLvl;
            Vehicles v = new Vehicles(fuelLvl, GetRegPlate, GetRentalPrice, GetVehicleType, GetFuelType, GetMake, GetModel, GetBodyType, GetColor, GetRental, GetMileage);
            meContext.Vehicle.Add(v);
            meContext.SaveChanges();

        }

        public void addVehicles(Vehicles v)
        {
            Console.WriteLine("Please enter the make of the Vehicle (I.E Ford)");
            v.GetMake = Console.ReadLine();
            Console.WriteLine("Please enter the Model of the Vehicle (I.E Focus)");
            v.GetModel = Console.ReadLine();
            Console.WriteLine("Please enter the Color of the Vehicle (I.E Blue)");
            v.GetColor = Console.ReadLine();
            Console.WriteLine("Please enter the Vehicle type of the Vehicle (I.E Super Saloon or Sports)");
            v.GetVehicleType = Console.ReadLine();
            Console.WriteLine("Please enter the Mileage of the Vehicle (I.E 12345)");
            v.GetMileage = int.Parse(Console.ReadLine());
            Console.WriteLine("Please enter the Fuel Type of the Vehicle (I.E Hybrid)");
            v.GetFuelType = Console.ReadLine();
            Console.WriteLine("Please enter the Body Type type of the Vehicle (I.E Estate)");
            v.GetBodyType = Console.ReadLine();
            Console.WriteLine("Please enter the Registration Plate of the Vehicle (I.E MA68JRP)");
            v.GetRegPlate = Console.ReadLine();
            Console.WriteLine("Finally, Please enter the Rental Price of the Vehicle (I.E 9.99)");
            v.GetRentalPrice = double.Parse(Console.ReadLine());
            meContext.Vehicle.Add(v);
            meContext.SaveChanges();
            Console.WriteLine("Vehicle Added");
            Thread.Sleep(3000);
        }

        public void removeVehicles(List<Vehicles> a)
        {
            for (int i = 0; i < a.Count; i++)
            {
                Console.WriteLine(a[i].ToString());
            }
            Console.WriteLine("Please Specify the Vehicle You would like to remove by Registration Plate");
            string registration = Console.ReadLine().ToUpper();
            var db = meContext.Vehicle.Where(u => u.GetRegPlate.ToUpper().Equals(registration)).FirstOrDefault();
            if (db == null) { Console.WriteLine("No Records Found"); }
            else
            {
                Console.WriteLine("Removed: " + db.ToString());
                meContext.Vehicle.Remove(db);
                meContext.SaveChanges();
                Thread.Sleep(3000);
            }
        }

        public override string ToString()
        {
            string s = GetRegPlate +  " " + GetRentalPrice.ToString() + " " + GetVehicleType + " " +  GetMake + " " + GetModel +  " " + GetBodyType + " " + GetColor + " " + GetRental + " " + GetMileage.ToString() + " " + fuelLvl.ToString();
            return s;
        }
    }
    
}
